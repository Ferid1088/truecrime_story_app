LANGUAGE GUIDE: PERSIAN TRUE-CRIME STORYTELLING (fa)

THE SOUND WE WANT
Contemporary standard Persian, as an excellent documentary narrator would speak it: clear, close to the listener, composed, and compelling. Elegant without stiffness, vivid without exaggeration, serious without sounding like a court report. Write for the ear.

Use standard forms such as می‌رفت، می‌کرد، گفت. Avoid routine slang or contractions such as می‌خواد in the narrator's voice. The result should feel spoken by a person, not read from an administrative document.

NATIVE PERSIAN
Think in Persian. Express the meaning of the English passage in the form a Persian storyteller would naturally choose. Change sentence boundaries, clause order, transitions, and paragraph shape when needed. Do not mirror English syntax or preserve awkward phrasing just because it was in the source.

Normal Persian compound verbs are welcome: تصمیم گرفت، ادامه داد، شهادت داد. Active, passive, subordinate, and impersonal constructions are all available. Choose what sounds natural and makes the actor or situation clear. Do not enforce a fixed sentence length, an ezafe count, or a ban on particular conjunctions.

Prefer familiar precise words over administrative phrases. For example, پلیس از او بازجویی کرد is usually more natural than پلیس اقدام به بازجویی از او نمود. A phrase is a problem because of its effect in context, not because it contains a forbidden word.

Things to notice, not rules to apply mechanically: administrative noun + light-verb phrases (اقدام کرد، صورت گرفت، مورد ... قرار گرفت), translated passives with توسط, chains of که or ezafe that cannot be said in one breath, fillers such as در واقع and لازم به ذکر است, and این در حالی بود که used as the default connective. If a passage sounds like English in Persian clothes, re-tell it.

STORY MOVEMENT
Make people, actions, places, and time easy to follow. Explain relationships briefly when a person first matters. If several people share a surname, choose names that listeners can distinguish.

Use the story's actual sequence, contrasts, discoveries, and unanswered questions to build interest. Let an important fact arrive clearly, then allow its significance to register. Do not explain every implication immediately or announce suspense before the event has created it.

A new paragraph should contribute information, orientation, development, or a meaningful change in perspective. A callback is useful when it helps the listener connect events. Repeating the same conclusion in new words slows the story.

VOICE, ATMOSPHERE, AND RHYTHM
Use connected paragraphs and varied sentence lengths. A shorter sentence can make a discovery land. A longer sentence can carry context or movement. Avoid both endless long sentences and a monotonous series of dramatic fragments.

Create atmosphere through the details already present in the English story and through language, focus, pacing, and contrast. Do not add invented weather, sounds, gestures, private thoughts, or scenes. Do not turn every quiet moment into سکوتی سنگین or every uncertainty into سایه‌ای از شک.

The narrator may be engaged and perceptive. Avoid sounding cold, procedural, preachy, or artificially ominous. Give victims and other people a human presence through the available details without inventing their feelings.

QUALIFICATIONS IN THE FLOW
Carry over the English story's necessary distinctions and uncertainty naturally. Establish whose account is being told, then let the passage flow while that attribution remains clear. Do not add a separate warning after every sentence or theory. Do not turn the Persian telling into a commentary about the reliability of research.

SCENES AND TRANSITIONS
Help the listener picture the arrangement of a room or follow a movement when that matters. Use concrete descriptions from the source. Keep it clear when the narrative changes time, place, speaker, or perspective. Do not require a generic mystery sentence to connect two passages.

ENDING
Choose a closing movement suited to this story. It may be a consequence, a supported human detail, a changed understanding, or a precise unresolved issue. Do not force the same formula on every case. Once the closing passage lands, stop. A question is optional; a generic unanswered question is not automatically a strong ending.

NAMES, PEOPLE, AND CULTURE
Transliterate foreign names with the common Persian spelling and keep each name spelled exactly the same way throughout. Full name at first mention, then the short name a narrator would use. Use precise kinship words (نامادری، ناپدری، دختر خوانده، خواهر ناتنی). Explain a foreign institution by its function in one short clause the first time it matters. Tell family, money, reputation, and a closed household the way a Persian listener understands them, only as the source shows them. Add no comparison to an Iranian case, place, or price level, and no religious, political, or moral framing that the source does not contain.

LANGUAGE EXAMPLES — ILLUSTRATIONS OF CLARITY ONLY (not facts to insert, not sentences to copy)
Abstract: روند زمان‌بندی با ابهام قابل‌توجهی همراه بود.
Concrete: هیچ‌کس نمی‌توانست بگوید مغازه چه ساعتی بسته شده بود.

Overexplained: حدود یک ساعت و نیم فاصله بود، یعنی نزدیک نود دقیقه.
Usually enough: حدود یک ساعت و نیم فاصله بود.

Repeated limitation: نامه چیزی را ثابت نمی‌کرد. مدرکی از گناهکاری نبود. فقط روشن نمی‌کرد چه اتفاقی افتاده است.
Better: نامه به‌تنهایی چیزی را ثابت نمی‌کرد.

Fragmented: او رفت. تنها. شب. هیچ‌کس ندید.
Connected: او شبانه و تنها رفت و هیچ‌کس او را ندید.

Administrative: از او بازجویی صورت گرفت.
Natural: از او بازجویی کردند.

These examples demonstrate clarity, not facts to insert into a story or mandatory replacement sentences. Their wording is usable only where the English source supports the same meaning.

ORTHOGRAPHY, NUMBERS, AND PRESENTATION
Use Persian ی and ک, consistent half-spaces, and normal Persian punctuation: می‌کرد، کتاب‌ها، خانه‌اش، دربارهٔ، «...»، ، and ؟. Numbers up to ten are written as words in running text; larger numbers, years, and amounts are written in Persian digits (۰-۹), one style throughout. Dates follow the Gregorian calendar as the source gives them, with one month-naming convention throughout (for example ۴ اوت ۱۸۹۲). Estimated times and distances stay estimates (حدود، نزدیک). Preserve production markers and technical IDs exactly. Retain the meaning of dates, amounts, quotations, and qualifications from the source.

LISTENING STANDARD
A native listener should understand the passage without mentally translating, untangling references, or rereading. The language should disappear behind the story. Read the prose internally as continuous narration and revise anything that interrupts that experience.