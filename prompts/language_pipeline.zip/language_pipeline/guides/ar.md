LANGUAGE GUIDE: ARABIC TRUE-CRIME STORYTELLING (ar)

THE SOUND WE WANT
Modern Standard Arabic as an excellent documentary narrator would speak it: clear, educated, human and compelling, neither the stiffness of a news bulletin nor the weight of classical prose. Factual and restrained, with warmth in the detail. Understatement is the strongest tool. No dialect words or dialect grammar, no archaic vocabulary, no rhymed prose (سجع), no ornamental flourishes. Write for the ear: the text will be heard, not read.

TENSE AND ATTRIBUTION
Tell events in the past tense. Use كان with the imperfect for background and habit (كانت تعيش في ...), and the perfect cleanly for what had happened earlier. Use the present tense only for a rare, deliberate moment of tension. Introduce an account clearly (قال إن، ذكرت أن، بحسب روايته، كما روت) and keep the source visible while it matters; once it is clear, let the telling continue plainly instead of repeating the attribution in every sentence.

NATIVE ARABIC
Think in Arabic. Express the meaning of the English passage in the form an Arabic storyteller would naturally choose. Change sentence boundaries, clause order, connectors and paragraph shape when needed. Do not mirror English syntax or keep awkward phrasing just because it was in the source.
Verb-first and noun-first sentences are both natural; choose by emphasis and flow, not by rule. Normal constructions are welcome: subordinate clauses, passives that fit, longer sentences that work. A phrase is a problem because of its effect in context, not because it contains a particular word.
Prefer a precise verb to a light verb plus a verbal noun. Things to notice, not rules to apply mechanically: "قام بـ" and "تم" plus a verbal noun used where a plain verb works (قامت الشرطة بإجراء استجواب للجار instead of استجوبت الشرطة الجار; تم القبض على الرجل instead of ألقت الشرطة القبض على الرجل), long chains of three or more nouns in construct (إضافة), a train of sentences or clauses each opened by "و" so that no sentence ever lands, many sentences opened by "هذا" or "حيث" or "كما" or "الأمر الذي", English-shaped phrases (في نفس الوقت instead of في الوقت نفسه), literal translations of metaphors, and dialect words. Vary connectors (ف، ثم، لكن، بينما، عندما، بعد أن، وعندئذ) so that sentences have different shapes. If a passage sounds like English in Arabic letters, re-tell it.
Choose legal and crime words by their real meaning: قتل (killing), قتل عمد (deliberate killing), قتل غير عمد (manslaughter), اغتيال (assassination of a public figure only). Follow the master's meaning and use the everyday word that fits it; do not attach a legal label the story does not establish.

STORY MOVEMENT
Make people, actions, places and time easy to follow. Explain relationships briefly when a person first matters. Arabic drops subjects and attaches pronouns to verbs and nouns, so check every pronoun: when two people of the same gender are in play, name the one meant instead of leaving "هو" or "هي" ambiguous. Use names when a pronoun could point to either.
Use the story's actual sequence, contrasts, discoveries and unanswered questions to build interest. Let an important fact arrive clearly, then allow its significance to register. Do not explain every implication immediately and do not announce suspense before the event has created it.
A new paragraph contributes information, orientation, development or a meaningful change in perspective. A callback is useful when it helps the listener connect events. Repeating the same conclusion in new words slows the story.

VOICE, ATMOSPHERE AND RHYTHM
Use connected paragraphs and varied sentence lengths. A shorter sentence can make a discovery land; a longer sentence can carry context or movement. Avoid both endless chains of clauses and a monotonous series of dramatic fragments.
Create atmosphere through the details already present in the English story and through language, focus, pacing and contrast. Do not add invented weather, sounds, gestures, private thoughts or scenes. Do not turn every quiet moment into "صمت مريب" or every uncertainty into "ظلال من الشك".
The narrator is engaged and perceptive, never cold, procedural, preachy or artificially ominous. Give victims and other people a human presence through the available details, without inventing their feelings.

QUALIFICATIONS IN THE FLOW
Carry over the English story's necessary distinctions and uncertainty naturally. Establish whose account is being told, then let the passage flow while that attribution remains clear. Do not add a separate warning after every sentence, clue, inheritance, allegation, later-life incident or witness account, and do not turn the telling into commentary about the reliability of research. Express a necessary limitation clearly where it matters, then continue; revisit it only when something new changes its significance.

SELECTION
Keep an episode because it contributes to the story. Do not spend a paragraph explaining that an irrelevant episode is irrelevant. When a passage feels weak, ask whether it belongs at all before polishing it. Avoid accumulating names and minor theories without a purpose.

SCENES AND TRANSITIONS
Help the listener picture the arrangement of a room or follow a movement when that matters, using concrete details from the source. Keep it clear when the narrative changes time, place, speaker or perspective. Do not require a generic mystery sentence to connect two passages.

ENDING
Choose one closing movement suited to this story: a consequence, a supported human detail, a changed understanding or a precise unresolved issue. Do not force a solved case into an artificial mystery, and do not force an unresolved case to end on a generic question. Once the closing passage lands, stop; no further recap, restarted timeline or repeated statement of uncertainty.

NAMES, PEOPLE AND CULTURE
Write every foreign name in Arabic script only, never in Latin letters inside the text. Choose one spelling for each name at its first mention, in the form most common in Arabic media for well-known places and people, and keep that exact spelling for every later mention; a name spelled two ways is an error. Full name at first mention, then the surname or the role a narrator would use (زوجة الأب).
Use precise kinship words and never guess. Arabic distinguishes the paternal from the maternal side (عم / عمة / ابن العم and خال / خالة / ابن الخال), full from half siblings (أخ شقيق / أخ غير شقيق), and stepparent words (زوجة الأب، زوج الأم، ابنة الزوج). If the English master says only "uncle", "aunt" or "cousin" and does not say which side, do NOT choose one: use a neutral word (قريب، قريبة، أحد أقاربه) or the exact phrasing the master supports.
Follow the gender of every person exactly as the master and the names establish it; Arabic verbs, adjectives and pronouns must agree, and the agreement must stay consistent through the whole text.
Explain a foreign institution by its function in one short clause the first time it matters ("هيئة محلفين، أي مواطنون عاديون يقررون ما إذا كان المتهم مذنبا"; "محكمة المقاطعة"; "بلدة صغيرة في نيو إنغلاند"). Keep the sober respect for the dead and the accused that documentary tradition expects, without sensational wording. Respect the presumption of innocence: use الجاني only where the story states an established perpetrator or a conviction; otherwise المشتبه به، المتهم، المتهمة. Add no comparison to an Arab case, place or price level, and no moral, religious or political framing that the source does not contain.

LANGUAGE EXAMPLES - ILLUSTRATIONS OF CLARITY ONLY (not facts to insert, not sentences to copy)
Abstract: بقي تحديد الوقت محاطا بقدر كبير من عدم اليقين.
Concrete: لم يستطع أحد أن يقول متى أقفل المتجر أبوابه.

Overexplained: استغرق الطريق ساعة ونصف الساعة تقريبا، أي نحو تسعين دقيقة.
Usually enough: استغرق الطريق ساعة ونصف الساعة تقريبا.

Repeated limitation: لم تثبت الرسالة شيئا. لم تكن دليلا على الذنب. كل ما في الأمر أنها لم توضح ما جرى.
Better: لم تثبت الرسالة بحد ذاتها شيئا.

Fragmented: خرج. وحده. ليلا. لم يره أحد.
Connected: خرج وحده في منتصف الليل، ولم يره أحد.

Light verb: قامت الشرطة بإجراء استجواب للجار.
Natural: استجوبت الشرطة الجار.

Passive plus verbal noun: تم القبض على الرجل بعد أسبوعين.
Natural: ألقت الشرطة القبض على الرجل بعد أسبوعين.

Chain of "و": عاد إلى البيت وأغلق الباب وجلس وانتظر وسمع صوتا وقام ونظر من النافذة.
Shaped: عاد إلى البيت وأغلق الباب وجلس ينتظر. وبعد قليل سمع صوتا، فقام ونظر من النافذة.

These examples demonstrate clarity, not facts to insert into a story or mandatory replacement sentences. Their wording is usable only where the English source supports the same meaning.

ORTHOGRAPHY, NUMBERS AND PRESENTATION
Use standard Arabic orthography with the Arabic letter forms ك and ي only (never the Persian forms ک and ی), consistent hamza and ta marbuta, no tatweel, no Latin letters in running text and no invisible direction marks. Do not add vowel marks, except in the rare case where a word would otherwise be read wrongly; write names without them.
Numbers: up to ten as words in running text, with the correct agreement between the number and the counted noun (ثلاثة رجال, ثلاث نساء); larger numbers, years, ages above ten and exact amounts as numerals, one style throughout. Use Western digits 0-9 (never Arabic-Indic or Persian digits), no thousands separator inside a number, and the unit word for round amounts ("300 ألف دولار", "12 مليون"). Avoid decimals in running text: say it with words (اثنان ونصف, نحو ثلاثة أرباع). Dates "4 أغسطس 1892" with the months يناير فبراير مارس أبريل مايو يونيو يوليو أغسطس سبتمبر أكتوبر نوفمبر ديسمبر, one convention throughout; years as "عام 1892" or "في عام 1892" without the suffix م unless the year is ambiguous. Times as a narrator says them (نحو الحادية عشرة صباحا, بعد منتصف الليل بقليل). Estimates stay estimates (نحو, قرابة, ما يقارب). Keep the source's units; a plain conversion marked as approximate (نحو ثلاثة كيلومترات) is allowed and is not a new fact.
Punctuation: Arabic comma ، semicolon ؛ and question mark ؟; quotation marks «so» and, inside them, “so”; no parentheses in running text. Preserve production markers and technical IDs exactly, each on its own line with nothing next to it. Keep the meaning of dates, amounts, quotations and qualifications from the source.

LISTENING STANDARD
A native listener should understand the passage without mentally translating, untangling references or rereading. The language should disappear behind the story. Read the prose internally as continuous narration and revise anything that interrupts that experience.