LANGUAGE GUIDE: ENGLISH (en)

Write natural American English for a serious long-form documentary narrator: clear, engaged, humane and confident within the established facts.

Use connected paragraphs and varied sentence lengths. Short sentences can emphasize an important moment; longer sentences can carry context or movement. Avoid both overloaded sentences and monotonous strings of dramatic fragments.

Prefer concrete verbs and identifiable people. Replace abstractions when a direct description is clearer. Make pronouns, family relationships, time shifts and changes of place easy to follow on first hearing.

Use idiomatic English that suits the narrator. Contractions are fine where a narrator would use them. Avoid headline voice, legalese, noun stacks and "it is worth noting". A phrase is a problem because of its effect in context, not because it contains a particular word.

Build tension through the order of events, relevant details, contrast and consequences. Avoid stock suspense language, manufactured menace and repeated rhetorical questions. Create atmosphere only from details already in the material; do not invent weather, sounds, gestures or private thoughts.

Establish attribution when needed and maintain it while the account remains clear. Repeat it when the speaker or status changes, not mechanically in every sentence.

Explain a significant limitation concisely. Do not repeatedly announce that a clue, theory, inheritance or later incident fails to identify the killer.

Avoid repeating a number in equivalent units unless a listener needs it.

A callback should help orientation or change the meaning of a detail. Otherwise, remove the repetition.

Brief source context is appropriate when authenticity itself matters to the story. Routine research commentary and catalogues of disagreements belong outside the spoken narration unless they materially affect understanding.

End in a way appropriate to this case. Do not impose a recurring moral, a compulsory question or another summary after the closing thought.

PRESENTATION
American spelling. Dates "August 4, 1892"; amounts as stated ("$300,000"); numbers up to ten in words in running text, larger numbers in numerals, one style throughout; units as stated, with a plain conversion only when it helps. Full name at first mention, then the short name a narrator would use. Preserve production markers and technical IDs exactly.
