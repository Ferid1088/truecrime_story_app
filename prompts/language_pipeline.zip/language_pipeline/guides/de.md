LANGUAGE GUIDE: GERMAN TRUE-CRIME STORYTELLING (de)

THE SOUND WE WANT
Standard contemporary German as an excellent documentary narrator would speak it, in the tradition of the good radio feature: sober, precise, human and compelling. Factual and restrained, with warmth in the detail. Understatement is the strongest tool. Not newsroom German, not the German of an administrative notice, not slang. Write for the ear.

TENSE AND REPORTED SPEECH
Tell events in the Präteritum. Use the Präsens only for a rare, deliberate moment of tension. Use the Perfekt in quoted speech and in direct address. Use the Plusquamperfekt cleanly for what had happened earlier. When an account is reported, introduce it clearly (sagte, erzählte, gab an, nach ihrer Darstellung); indirect speech with the Konjunktiv I helps where the source must stay visible, but do not carry the Konjunktiv through whole paragraphs: once the source is clear, let the telling continue plainly.

NATIVE GERMAN
Think in German. Express the meaning of the English passage in the form a German storyteller would naturally choose. Change sentence boundaries, clause order, transitions and paragraph shape when needed. Do not mirror English syntax or keep awkward phrasing just because it was in the source.
Normal constructions are welcome: subordinate clauses, passives that fit, longer sentences that work. Keep the Satzklammer short enough that the listener can hold the verb. Do not enforce a fixed sentence length or ban particular constructions. A phrase is a problem because of its effect in context, not because it contains a particular word.
Prefer familiar precise words and verbs over administrative noun style. Things to notice, not rules to apply mechanically: Nominalstil and Behördendeutsch ("Es erfolgte eine Vernehmung" instead of "Die Polizei vernahm ihn"), stacked passives with "wurde ... durchgeführt", English-shaped calques and false friends ("Das macht Sinn", "am Ende des Tages", "in 1892" instead of "1892" or "im Jahr 1892", "realisieren" for "erkennen", "eventuell" for "eventually", "aktuell" for "actually", "Ich denke, dass ..." openings, many sentences opening with "Dies"), unnecessary Anglicisms, filler such as "quasi" and "irgendwie", and literal metaphors. If a passage sounds like English in German clothes, re-tell it.
Choose legal and crime words by their real meaning: "Mord", "Totschlag" and "Tötung" are different things; follow the master's meaning and use the everyday word that fits it (töten, ermorden) rather than a legal label the story does not establish. "Gift" means poison; use it deliberately.

STORY MOVEMENT
Make people, actions, places and time easy to follow. Explain relationships briefly when a person first matters. If several people share a surname, choose names that listeners can distinguish.
Use the story's actual sequence, contrasts, discoveries and unanswered questions to build interest. Let an important fact arrive clearly, then allow its significance to register. Do not explain every implication immediately and do not announce suspense before the event has created it.
A new paragraph contributes information, orientation, development or a meaningful change in perspective. A callback is useful when it helps the listener connect events. Repeating the same conclusion in new words slows the story.

VOICE, ATMOSPHERE AND RHYTHM
Use connected paragraphs and varied sentence lengths. A shorter sentence can make a discovery land; a longer sentence can carry context or movement. Avoid both endless Schachtelsätze and a monotonous series of dramatic fragments.
Create atmosphere through the details already present in the English story and through language, focus, pacing and contrast. Do not add invented weather, sounds, gestures, private thoughts or scenes. Do not turn every quiet moment into "eine unheimliche Stille" or every uncertainty into "ein Schatten des Zweifels".
The narrator is engaged and perceptive, never cold, procedural, preachy or artificially ominous. Give victims and other people a human presence through the available details, without inventing their feelings.

QUALIFICATIONS IN THE FLOW
Carry over the English story's necessary distinctions and uncertainty naturally. Establish whose account is being told, then let the passage flow while that attribution remains clear. Do not add a separate warning after every sentence, clue, inheritance, allegation, later-life incident or witness account, and do not turn the telling into commentary about the reliability of research. Express a necessary limitation clearly where it matters, then continue; revisit it only when something new changes its significance.

SELECTION
Keep an episode because it contributes to the story. Do not spend a paragraph explaining that an irrelevant episode is irrelevant. When a passage feels weak, ask whether it belongs at all before polishing it. Avoid accumulating names and minor theories without a purpose.

SCENES AND TRANSITIONS
Help the listener picture the arrangement of a room or follow a movement when that matters, using concrete details from the source. Keep it clear when the narrative changes time, place, speaker or perspective. Do not require a generic mystery sentence to connect two passages.

ENDING
Choose one closing movement suited to this story: a consequence, a supported human detail, a changed understanding or a precise unresolved issue. Do not force a solved case into an artificial mystery, and do not force an unresolved case to end on a generic question. Once the closing passage lands, stop; no further recap, restarted timeline or repeated statement of uncertainty.

NAMES, PEOPLE AND CULTURE
Keep foreign names in their original spelling. Full name at first mention, then the surname or the role a narrator would use ("die Stiefmutter"). Use the precise kinship words (Stiefmutter, Stieftochter, Halbschwester). Explain a foreign institution by its function in one short clause the first time it matters ("Geschworene, Laien, die über die Schuld entscheiden"; "ein Bezirksgericht"; "eine Kleinstadt in Neuengland"). Keep the sober respect for the dead and the accused that German documentary tradition expects, without sensational wording. Respect the presumption of innocence: use "der Täter" or "die Täterin" only where the story states an established perpetrator or a conviction; otherwise "der Tatverdächtige", "die Angeklagte". Add no comparison to a German case, place or price level, and no moral or political framing that the source does not contain.

LANGUAGE EXAMPLES - ILLUSTRATIONS OF CLARITY ONLY (not facts to insert, not sentences to copy)
Abstract: Die zeitliche Einordnung blieb mit erheblichen Unsicherheiten behaftet.
Concrete: Niemand konnte sagen, wann der Laden geschlossen hatte.

Overexplained: Der Weg dauerte etwa anderthalb Stunden, also ungefähr neunzig Minuten.
Usually enough: Der Weg dauerte etwa anderthalb Stunden.

Repeated limitation: Der Brief bewies nichts. Er war kein Beleg für Schuld. Er klärte lediglich nicht, was geschehen war.
Better: Der Brief bewies für sich genommen nichts.

Fragmented: Er ging. Allein. Nachts. Niemand sah ihn.
Connected: Er ging allein und mitten in der Nacht, und niemand sah ihn.

Nominal style: Es erfolgte eine Vernehmung des Nachbarn.
Natural: Die Polizei vernahm den Nachbarn.

Calque: In 1892 zog die Familie um.
Natural: 1892 zog die Familie um.

These examples demonstrate clarity, not facts to insert into a story or mandatory replacement sentences. Their wording is usable only where the English source supports the same meaning.

ORTHOGRAPHY, NUMBERS AND PRESENTATION
Current German orthography. Dates "4. August 1892". Thousands with a period and decimals with a comma ("300.000 Dollar", "2,5"); amounts in the currency the source states. Numbers up to twelve are written as words in running text; larger numbers, years and amounts as numerals, one style throughout. Times as a narrator says them ("gegen elf Uhr vormittags", "kurz nach Mitternacht"). Estimates stay estimates ("etwa", "rund", "gut"). Keep the source's units; a plain conversion marked as approximate ("rund drei Kilometer") is allowed and is not a new fact. Quotation marks „so“ and, inside them, ‚so‘; an Gedankenstrich only where it helps the ear; no semicolon runs. Preserve production markers and technical IDs exactly. Keep the meaning of dates, amounts, quotations and qualifications from the source.

LISTENING STANDARD
A native listener should understand the passage without mentally translating, untangling references or rereading. The language should disappear behind the story. Read the prose internally as continuous narration and revise anything that interrupts that experience.