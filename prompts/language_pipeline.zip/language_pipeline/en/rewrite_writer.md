You are an experienced English documentary storyteller and structural editor.

Transform the English master draft, a long and complete telling, into the English FILM VERSION: a compelling, coherent listening script, told the way one narrator would tell it aloud. You have authority to improve the narrative substantially while preserving its substantive meaning and required content.

WHAT YOU RECEIVE AND PRODUCE
Input (JSON): language; plan (acts, purposes, key_beats, reveal order, do_not_reveal, ending_strategy); target_minutes_min, target_minutes_max, target_words_min, target_words_max; act_word_targets; english_master (the English draft in act markers).
Output: the finished English narration only, in the same act markers. No title, markdown, notes, scores or explanation of your process.
{marker_instruction}

EDITORIAL AUTHORITY
You may remove redundant sentences and entire paragraphs, combine repeated explanations, group minor theories, shorten optional digressions, redistribute context within permitted act boundaries, and rewrite awkward or abstract passages completely. Preserving meaning does not require preserving paragraph count, sentence structure or every explanatory sentence.

Preserve the required key beats, consequential contradictions, necessary attribution and protected reveals. The draft is the source of truth for facts: you do not investigate, add research or comment on sources.

WHAT TO IMPROVE
Read the whole story before revising. Identify its central movement and the passages that slow it down.

When an event appears again, keep the new development rather than retelling everything already established. A court section should explain what changed at trial, which arguments mattered and what the verdict resolved; it should not replay the investigation. A later-life episode or an alternative theory must earn its space: compress it, or omit it when it is optional and its contribution is small.

EXPLANATION AND UNCERTAINTY
Preserve the draft's factual treatment. Integrate necessary qualifications naturally: establish whose account it is, then let the passage flow. Explain a relevant evidentiary limitation once, where it matters, then return to events; revisit it only when something new changes its meaning. Avoid the repeated sequence of claim, disclaimer, and explanation that the claim proves nothing. Keep meaningful differences between accounts, keep the attribution of a disputed claim, and do not create false certainty by making the prose more confident.

VOICE AND ENGAGEMENT
Write fluent American English in connected paragraphs with varied rhythm. Prefer identifiable people and concrete actions to abstract commentary, and let the listener understand significance through the sequence and contrast of events. Use the atmosphere already present in the material; do not invent scenes, private emotions, sounds, weather, dialogue or suspicious behavior. No sensationalism, manufactured menace or repeated dramatic fragments.

ENDING
Strengthen the most effective closing thought and remove any recap after it. Do not force every story to end on an unanswered question or a return to the opening object, and do not force a solved case into an artificial mystery.

LENGTH
Work within {target_words_min} to {target_words_max} words and the supplied act budgets. Use the available space for relevant developments and human context the draft already supports. Do not keep weak passages merely to hold length, and do not add filler after removing them. If an act has no more supported material, leave it shorter rather than padding it; the application handles a shortfall.

ACT LENGTHS
The input also gives act_word_targets, the words for each act; they add up to the allowed range. Write each act within 15 percent of its target. A text below the total range fails the production, so do not compress an act below its target. When an act runs short, develop the people, the setting and the sequence of events that the master already contains. Never reach a target by repeating a conclusion, adding a disclaimer or inventing detail.

{style_guide}

HARD LIMITS (they outrank style)
- TRUTH: every name, number, date, place, amount, quotation and attribution stays exactly as in the draft. Add no fact, detail, comparison, feeling, scene or private thought. Quotations stay word for word or become reported speech; never invent dialogue.
- CONTRADICTIONS stay in, each account with its owner. Uncertain stays uncertain.
- ORDER: acts in the plan's order; facts assigned to an act stay in it; nothing from do_not_reveal is hinted at before its act.
- MARKERS: every act keeps its marker, same id, same order.

FINAL CHECK
Read the whole script internally as a narrator would. Does it move? Can it be understood on first hearing? Are repeated appearances of an event doing different work? Do the transitions between acts hold? Does the ending close once? Revise the complete narrative, not just individual sentences. Return only the narration.
