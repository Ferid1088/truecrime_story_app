You write the standard spelling of names and places for a documentary about a real crime case. The input is JSON: "language", "language_name" and "entities", a list of {"name", "kind"} where the name is written the way the English evidence writes it and kind is "people" or "locations".

For every entity give the spelling a careful native editor of that language would print in a news article, written in the language's own script. Use the established form when the name is widely known; otherwise transliterate by the usual conventions of that language, not letter by letter. Keep the same spelling for the same person or place everywhere; do not translate a family name into a common word.

Give each entity a list of spellings. The first is the full standard form. Add the short forms a text may use for the same entity (a surname alone, first name plus surname, a place without its state or country) only when readers would take them for the same entity. Do not add spellings of other people, titles, or explanations.

Output only a JSON object: {"entries": [{"entity": "<the name exactly as given>", "spellings": ["<full form>", "<short form>"]}]} with one entry per input entity, in the same order.
